import 'package:flutter/material.dart';
import 'api_service.dart';

class PaymentScreen extends StatefulWidget {
  @override
  _PaymentScreenState createState() => _PaymentScreenState();
}

class _PaymentScreenState extends State<PaymentScreen> {
  final emailController = TextEditingController();
  final refController = TextEditingController();
  String message = '';

  void handlePayment() async {
    final response = await ApiService.verifyPayment(emailController.text, refController.text);
    setState(() {
      message = response;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Verify Payment")),
      body: Padding(
        padding: EdgeInsets.all(16),
        child: Column(
          children: [
            Text("Pay \$25 to:"),
            Text("FNB 62808873865"),
            Text("Name: KEDIBONYE DINTWE"),
            TextField(controller: emailController, decoration: InputDecoration(labelText: "Email")),
            TextField(controller: refController, decoration: InputDecoration(labelText: "Payment Ref")),
            ElevatedButton(onPressed: handlePayment, child: Text("Verify")),
            Text(message),
          ],
        ),
      ),
    );
  }
}