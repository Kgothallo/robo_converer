import 'package:flutter/material.dart';

class UploadBotScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Upload Bot")),
      body: Center(
        child: Text("Bot upload functionality goes here."),
      ),
    );
  }
}