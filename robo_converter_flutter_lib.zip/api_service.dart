import 'dart:convert';
import 'package:http/http.dart' as http;

class ApiService {
  static const String baseUrl = 'https://your-vercel-backend.vercel.app/api';

  static Future<String> register(String name, String email, String password) async {
    final response = await http.post(
      Uri.parse('$baseUrl/register'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({'name': name, 'email': email, 'password': password}),
    );
    return jsonDecode(response.body)['message'];
  }

  static Future<String> login(String email, String password) async {
    final response = await http.post(
      Uri.parse('$baseUrl/login'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({'email': email, 'password': password}),
    );
    return jsonDecode(response.body)['message'];
  }

  static Future<String> verifyPayment(String email, String ref) async {
    final response = await http.post(
      Uri.parse('$baseUrl/verify-payment'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({'email': email, 'ref': ref}),
    );
    return jsonDecode(response.body)['message'];
  }
}